package com.raeyncraft.matrixcraft.client;

import com.raeyncraft.matrixcraft.MatrixCraftConfig;
import com.raeyncraft.matrixcraft.MatrixCraftMod;
import com.raeyncraft.matrixcraft.particle.MatrixParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@EventBusSubscriber(value = Dist.CLIENT, modid = MatrixCraftMod.MODID)
public class BulletImpactTracker {

    private static final Map<Integer, Vec3> trackedBullets = new HashMap<>();
    private static final Set<Integer> processedImpacts = new HashSet<>();

    @SubscribeEvent
    public static void onBulletJoin(EntityJoinLevelEvent event) {
        if (!(event.getLevel() instanceof ClientLevel level)) return;
        Entity entity = event.getEntity();
        if (!isTaczBullet(entity)) return;
        trackedBullets.put(entity.getId(), entity.position());
        MatrixCraftMod.LOGGER.debug("[BulletImpact] Tracking bullet {}", entity.getId());
    }

    @SubscribeEvent
    public static void onBulletLeave(EntityLeaveLevelEvent event) {
        if (!(event.getLevel() instanceof ClientLevel level)) return;
        Entity entity = event.getEntity();
        if (!isTaczBullet(entity)) return;

        int id = entity.getId();
        if (processedImpacts.contains(id)) return;

        Vec3 impactPos = trackedBullets.getOrDefault(id, entity.position());
        MatrixCraftMod.LOGGER.debug("[BulletImpact] Impact detected for bullet {} at {}", id, impactPos);
        createImpactEffect(impactPos, level);
        processedImpacts.add(id);
        trackedBullets.remove(id);
    }

    private static boolean isTaczBullet(Entity entity) {
        String cls = entity.getClass().getName().toLowerCase();
        String type = String.valueOf(entity.getType()).toLowerCase();
        return cls.contains("bullet") || cls.contains("kinetic") || type.contains("tacz") || type.contains("bullet");
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (!MatrixCraftConfig.IMPACT_LIGHTING_ENABLED.get()) return;

        Set<Integer> currentBullets = new HashSet<>();

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!isTaczBullet(entity)) continue;
            int id = entity.getId();
            currentBullets.add(id);
            trackedBullets.put(id, entity.position());
        }

        for (Integer id : new HashSet<>(trackedBullets.keySet())) {
            if (!currentBullets.contains(id) && !processedImpacts.contains(id)) {
                Vec3 impactPos = trackedBullets.get(id);
                if (impactPos != null) {
                    MatrixCraftMod.LOGGER.info("[BulletImpact] Impact detected for bullet {} at {}", id, impactPos);
                    createImpactEffect(impactPos, (ClientLevel) mc.level);
                    processedImpacts.add(id);
                }
                trackedBullets.remove(id);
            }
        }

        if (mc.player.tickCount % 200 == 0) {
            processedImpacts.clear();
        }
    }

    private static void createImpactEffect(Vec3 pos, ClientLevel level) {
        if (BulletTrailLighting.isDynamicLightingEnabled()) {
            int brightness = MatrixCraftConfig.IMPACT_LIGHT_LEVEL.get();
            int duration = MatrixCraftConfig.IMPACT_LIGHT_DURATION.get();
            float[] color = BulletTrailLighting.getTrailColor();
            BulletTrailLighting.addImpactLight(pos.x, pos.y, pos.z, brightness, duration, color[0], color[1], color[2]);
        }

        int particleCount = MatrixCraftConfig.IMPACT_PARTICLE_COUNT.get();
        double spread = MatrixCraftConfig.IMPACT_PARTICLE_SPREAD.get();

        for (int i = 0; i < particleCount; i++) {
            double ox = (Math.random() - 0.5) * spread;
            double oy = (Math.random() - 0.5) * spread;
            double oz = (Math.random() - 0.5) * spread;

            double vx = (Math.random() - 0.5) * 0.1;
            double vy = (Math.random() - 0.5) * 0.1;
            double vz = (Math.random() - 0.5) * 0.1;

            level.addAlwaysVisibleParticle(
                MatrixParticles.BULLET_IMPACT.get(),
                true,
                pos.x + ox, pos.y + oy, pos.z + oz,
                vx, vy, vz
            );
        }
    }

    private static boolean isTaczBullet(Entity entity) {
        return entity.getClass().getName().equals("com.tacz.guns.entity.EntityKineticBullet")
                || String.valueOf(entity.getType()).toLowerCase().contains("tacz");
    }
}