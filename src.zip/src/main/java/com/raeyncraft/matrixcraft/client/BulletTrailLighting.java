package com.raeyncraft.matrixcraft.client;

import com.raeyncraft.matrixcraft.MatrixCraftConfig;
import com.raeyncraft.matrixcraft.MatrixCraftMod;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages dynamic lighting for bullet trails.
 * Integrates with LambDynamicLights if available, otherwise provides
 * data that shaders can use for custom lighting effects.
 * 
 * LambDynamicLights API: We register light sources at particle positions
 * that decay over time as the trail fades.
 */
@OnlyIn(Dist.CLIENT)
public class BulletTrailLighting {
    
    // Track active light sources: position -> (brightness, ticksRemaining)
    private static final Map<BlockPos, LightSource> activeLights = new ConcurrentHashMap<>();
    
    // LambDynamicLights availability flag
    private static boolean lambDynLightsAvailable = false;
    private static boolean checkedForLambDynLights = false;
    
    // Light settings
    private static final int MAX_LIGHT_LEVEL = 12; // Max brightness (0-15)
    private static final int LIGHT_DURATION_TICKS = 15; // How long lights last
    private static final int MAX_LIGHTS = 200; // Prevent too many light sources
    
    private static class LightSource {
        int brightness;
        int ticksRemaining;
        int maxTicks;
        
        LightSource(int brightness, int duration) {
            this.brightness = brightness;
            this.ticksRemaining = duration;
            this.maxTicks = duration;
        }
        
        // Returns current brightness based on remaining time (fades out)
        int getCurrentBrightness() {
            float progress = (float) ticksRemaining / maxTicks;
            return (int) (brightness * progress);
        }
    }
    
    /**
     * Check if LambDynamicLights is available
     */
    public static boolean isLambDynLightsAvailable() {
        if (!checkedForLambDynLights) {
            checkedForLambDynLights = true;
            try {
                // Check if LambDynamicLights API class exists
                Class.forName("dev.lambdaurora.lambdynlights.api.DynamicLightHandlers");
                lambDynLightsAvailable = true;
                MatrixCraftMod.LOGGER.info("[BulletTrailLighting] LambDynamicLights detected!");
            } catch (ClassNotFoundException e) {
                lambDynLightsAvailable = false;
                MatrixCraftMod.LOGGER.info("[BulletTrailLighting] LambDynamicLights not found, using fallback lighting");
            }
        }
        return lambDynLightsAvailable;
    }
    
    /**
     * Register a light source at a position (called when spawning trail particles)
     */
    public static void addLightSource(double x, double y, double z) {
        if (activeLights.size() >= MAX_LIGHTS) {
            // Remove oldest lights if at capacity
            pruneOldestLights(50);
        }
        
        BlockPos pos = BlockPos.containing(x, y, z);
        
        // Calculate brightness based on config color (brighter colors = more light)
        int brightness = calculateBrightnessFromConfig();
        
        activeLights.put(pos, new LightSource(brightness, LIGHT_DURATION_TICKS));
    }
    
    /**
     * Add multiple light sources along a trail segment
     */
    public static void addTrailSegmentLights(double x1, double y1, double z1, 
                                              double x2, double y2, double z2, 
                                              int numLights) {
        if (numLights <= 0) return;
        
        for (int i = 0; i < numLights; i++) {
            double t = (double) i / numLights;
            double x = x1 + (x2 - x1) * t;
            double y = y1 + (y2 - y1) * t;
            double z = z1 + (z2 - z1) * t;
            addLightSource(x, y, z);
        }
    }
    
    /**
     * Calculate light brightness from trail color config
     */
    private static int calculateBrightnessFromConfig() {
        try {
            int r = MatrixCraftConfig.TRAIL_COLOR_R.get();
            int g = MatrixCraftConfig.TRAIL_COLOR_G.get();
            int b = MatrixCraftConfig.TRAIL_COLOR_B.get();
            
            // Use perceived brightness formula
            // Green is perceived as brightest, then red, then blue
            double perceived = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;
            
            return (int) (MAX_LIGHT_LEVEL * perceived);
        } catch (Exception e) {
            return MAX_LIGHT_LEVEL / 2; // Default to medium brightness
        }
    }
    
    /**
     * Called every client tick to update light sources
     */
    public static void tick() {
        if (activeLights.isEmpty()) return;
        
        Iterator<Map.Entry<BlockPos, LightSource>> iterator = activeLights.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<BlockPos, LightSource> entry = iterator.next();
            LightSource light = entry.getValue();
            
            light.ticksRemaining--;
            
            if (light.ticksRemaining <= 0) {
                iterator.remove();
            }
        }
    }
    
    /**
     * Get the light level at a position (for LambDynamicLights integration)
     */
    public static int getLightLevel(BlockPos pos) {
        LightSource light = activeLights.get(pos);
        if (light != null) {
            return light.getCurrentBrightness();
        }
        return 0;
    }
    
    /**
     * Get all active light positions and their brightness
     * (Useful for shader integration)
     */
    public static Map<BlockPos, Integer> getActiveLights() {
        Map<BlockPos, Integer> result = new ConcurrentHashMap<>();
        for (Map.Entry<BlockPos, LightSource> entry : activeLights.entrySet()) {
            int brightness = entry.getValue().getCurrentBrightness();
            if (brightness > 0) {
                result.put(entry.getKey(), brightness);
            }
        }
        return result;
    }
    
    /**
     * Clear all light sources
     */
    public static void clearAll() {
        activeLights.clear();
    }
    
    /**
     * Prune oldest lights when at capacity
     */
    private static void pruneOldestLights(int count) {
        // Simple approach: remove lights with lowest remaining ticks
        activeLights.entrySet().stream()
            .sorted((a, b) -> Integer.compare(a.getValue().ticksRemaining, b.getValue().ticksRemaining))
            .limit(count)
            .map(Map.Entry::getKey)
            .forEach(activeLights::remove);
    }
    
    /**
     * Get count of active lights (for debugging)
     */
    public static int getActiveLightCount() {
        return activeLights.size();
    }
}
